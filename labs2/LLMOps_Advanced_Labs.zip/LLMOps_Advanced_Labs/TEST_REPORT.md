# Lab test report (SMOKE mode, sandbox: 1 CPU, no GPU, no model-hub access)

| Lab | Solution notebook | `check()` PASSes | GPU-only steps skipped | Seconds | Starter |
|---|---|---|---|---|---|
| L01 | EXECUTED | 3 | 0 | 1.1 | COMPILES |
| L02 | EXECUTED | 4 | 1 | 2.9 | COMPILES |
| L03 | EXECUTED | 3 | 1 | 2.3 | COMPILES |
| L04 | EXECUTED | 3 | 0 | 2.8 | COMPILES |
| L05 | EXECUTED | 4 | 1 | 2.9 | COMPILES |
| L06 | EXECUTED | 5 | 0 | 1.1 | COMPILES |
| L07 | EXECUTED | 5 | 0 | 1.1 | COMPILES |
| L08 | EXECUTED | 6 | 0 | 25.5 | COMPILES |
| L09 | EXECUTED | 5 | 0 | 1.2 | COMPILES |
| L10 | EXECUTED | 3 | 0 | 1.7 | COMPILES |
| L11 | EXECUTED | 3 | 0 | 1.3 | COMPILES |
| L12 | EXECUTED | 3 | 0 | 1.7 | COMPILES |
| L13 | EXECUTED | 5 | 0 | 32.2 | COMPILES |
| L14 | EXECUTED | 5 | 0 | 1.1 | COMPILES |
| L15 | EXECUTED | 4 | 0 | 1.9 | COMPILES |
| L16 | EXECUTED | 5 | 0 | 1.1 | COMPILES |
| L17 | EXECUTED | 4 | 0 | 1.1 | COMPILES |

FAILED details:

